<script src="//e-commerce.loc/public/js/bootstrap.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@tarekraafat/autocomplete.js@9.0.0/dist/js/autoComplete.min.js"></script>

<script>
    const autoCompleteJS = new autoComplete({
        selector: "#autoComplete",
        placeHolder: "Search for Food...",
        data: {
            src: ["Sauce - Thousand Island", "Wild Boar - Tenderloin", "Goat - Whole Cut"]
        },
        resultsList: {
            noResults: (list, query) => {
                // Create "No Results" message list element
                const message = document.createElement("li");
                message.setAttribute("class", "no_result");
                // Add message text content
                message.innerHTML = `<span>Found No Results for "${query}"</span>`;
                // Add message list element to the list
                list.appendChild(message);
            },
        },
        resultItem: {
            highlight: {
                render: true
            }
        }
    });
</script>