<link rel="stylesheet" href="//e-commerce.loc/public/css/fonts.css">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tarekraafat/autocomplete.js@9.0.0/dist/css/autoComplete.min.css">


<link rel="stylesheet" href="//e-commerce.loc/public/css/bootstrap.css">
<link rel="stylesheet" href="//e-commerce.loc/public/css/gbox.css">
<link rel="stylesheet" href="//e-commerce.loc/public/css/style.css">

<script src="//e-commerce.loc/public/js/e-commerce.js"></script>
<script src="//e-commerce.loc/public/js/web.js"></script>
<script src="//e-commerce.loc/public/js/gbox.js"></script>