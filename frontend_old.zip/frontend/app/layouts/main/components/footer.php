<div class="footer d-flex w-100">
    <div class="footer-copy">
        Copyright 2021 <span id="web_name"></span>. All Rights Reserved
    </div>

    <div class="text-right" style="margin-left: auto;">
        <span>
            <a href="#" class="footer-link">Карта сайта</a>
        </span>
        <span>
            <img src="https://inlegal.eu/wp-content/uploads/2019/05/visa-mastercard-paypal.png" width="128px">
        </span>
    </div>

</div>