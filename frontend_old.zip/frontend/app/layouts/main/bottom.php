    <?php require_once("components/footer.php"); ?>

</div>


<div class="mt-5"></div>

    <script> WEB.init() </script>

<?php require_once("resources/scripts.php"); ?>
</body>
</html>